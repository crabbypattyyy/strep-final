# throat segmentation > 2024-01-17 12:23pm
https://universe.roboflow.com/project-teehl/throat-segmentation

Provided by a Roboflow user
License: CC BY 4.0

